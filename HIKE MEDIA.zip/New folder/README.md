# Social media website using html,css,js - Octapia

It's an open source project. Anyone can use this without any copyright issue.

## Useful Links

- [Demo](https://mistersakil.github.io/social-media-website-using-html-css-js/)
- [Facebook](https://www.facebook.com/octapia.com.bd)
- [Buy Me A Coffee](https://www.upwork.com/agencies/~011335ddde8074293a)

## Features & Library Used

- Pure CSS
- Font Awesome
- Vanilla JS
- Responsive
- CSS Flexbox
- CSS Variables
